let name = "Linda"
let greeting = "Hi there"

// Create a function that logs out "Hi there, Linda!" when called

