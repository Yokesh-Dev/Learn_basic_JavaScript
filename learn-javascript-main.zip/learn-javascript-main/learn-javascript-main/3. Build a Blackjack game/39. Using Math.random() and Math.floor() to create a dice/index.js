let randomNumber = Math.random() * 6

console.log(randomNumber)

/* 

Write down all the possible values randomNumber can hold now!

 


*/