let name = 42
let greeting = "Hi, my name is "
let myGreeting = greeting + name
// console.log(myGreeting)

// let points = 4
// let bonusPoints = "10"

// let totalPoints = points + bonusPoints

console.log(4 + 5) 
console.log("2" + "4")
console.log("5" + 1)
console.log(100 + "100")