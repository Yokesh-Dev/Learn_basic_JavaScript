// Create a function (you decide the name) that logs out the number 42 to the console
// Call/invoke the function

